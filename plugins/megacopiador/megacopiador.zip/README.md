# facturacion_base
Plugin para FacturaScripts que permite copiar documentos fácilmente: presupuestos, pedidos, albaranes, facturas...
En desarrollo.

https://www.facturascripts.com